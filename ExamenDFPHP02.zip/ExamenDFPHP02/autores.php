<?php include 'cn.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Autores</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        
body {
    background: linear-gradient(to right, #f8f9fa, #e9ecef);
    font-family: 'Poppins', sans-serif;
    color: #333;
}


.container {
    max-width: 900px;
    margin-top: 40px;
    padding: 20px;
}


.header {
    text-align: center;
    margin-bottom: 30px;
    color: #0056b3;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1.5px;
}


.card {
    margin-top: 20px;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    background: white;
    transition: transform 0.3s ease-in-out;
}

.card:hover {
    transform: scale(1.02);
}


.btn-custom {
    background: linear-gradient(135deg, #007bff, #0056b3);
    color: white;
    border-radius: 8px;
    padding: 10px 18px;
    font-size: 1rem;
    transition: 0.3s ease-in-out;
    border: none;
}

.btn-custom:hover {
    background: linear-gradient(135deg, #0056b3, #003f80);
    transform: scale(1.05);
}

.btn-danger, .btn-warning {
    border-radius: 6px;
    transition: 0.3s ease-in-out;
}

.btn-danger:hover {
    background-color: #c82333;
    transform: scale(1.05);
}

.btn-warning:hover {
    background-color: #e0a800;
    transform: scale(1.05);
}


.form-label {
    font-weight: bold;
    color: #555;
}

.form-control {
    border-radius: 8px;
    border: 1px solid #ccc;
    transition: 0.3s ease-in-out;
}

.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 8px rgba(0, 123, 255, 0.3);
}


.table {
    background: white;
    border-radius: 12px;
    overflow: hidden;
}

.table th {
    background: linear-gradient(135deg, #007bff, #0056b3);
    color: white;
    text-align: center;
    padding: 14px;
    font-size: 1rem;
    text-transform: uppercase;
}

.table td {
    vertical-align: middle;
    text-align: center;
    padding: 14px;
    font-size: 0.95rem;
}


.alert {
    font-size: 1.1em;
    padding: 12px;
    border-radius: 8px;
}


a.btn-secondary {
    border-radius: 8px;
    padding: 12px 18px;
    margin-top: 20px;
    display: inline-block;
    font-size: 1rem;
    transition: 0.3s ease-in-out;
}

a.btn-secondary:hover {
    background-color: #6c757d;
    transform: scale(1.05);
}
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="header">
            <h2>Gestión de Autores</h2>
        </div>

        
        <div class="card shadow-lg">
            <h4 class="card-title">Agregar Autor</h4>
            <form action="autores.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">Nombres:</label>
                    <input type="text" name="nombres" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Apellidos:</label>
                    <input type="text" name="apellidos" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Alias:</label>
                    <input type="text" name="alias" class="form-control">
                </div>
                <button type="submit" name="crear_autor" class="btn btn-custom">Crear Autor</button>
            </form>
        </div>

        <?php
        if (isset($_POST['crear_autor'])) {
            $nombres = $_POST['nombres'];
            $apellidos = $_POST['apellidos'];
            $alias = $_POST['alias'];

            $sql = "INSERT INTO autor (nombres, apellidos, alias_de_autor) VALUES ('$nombres', '$apellidos', '$alias')";
            if ($conn->query($sql) === TRUE) {
                echo "<p class='alert alert-success mt-3'>Autor agregado correctamente.</p>";
            } else {
                echo "<p class='alert alert-danger mt-3'>Error: " . $conn->error . "</p>";
            }
        }

        if (isset($_POST['editar_autor'])) {
            $id = $_POST['id_autor'];
            $nombres = $_POST['nombres'];
            $apellidos = $_POST['apellidos'];
            $alias = $_POST['alias'];
            
            $sql = "UPDATE autor SET nombres='$nombres', apellidos='$apellidos', alias_de_autor='$alias' WHERE id_autor='$id'";
            if ($conn->query($sql) === TRUE) {
                echo "<p class='alert alert-success mt-3'>Autor actualizado correctamente.</p>";
            } else {
                echo "<p class='alert alert-danger mt-3'>Error: " . $conn->error . "</p>";
            }
        }

        if (isset($_POST['eliminar_autor'])) {
            $id = $_POST['id_autor'];
            
            // Eliminar primero los libros asociados
            $sql_libros = "DELETE FROM libros WHERE id_autor='$id'";
            $conn->query($sql_libros);

            // Luego eliminar el autor
            $sql = "DELETE FROM autor WHERE id_autor='$id'";
            if ($conn->query($sql) === TRUE) {
                echo "<p class='alert alert-success mt-3'>Autor eliminado correctamente.</p>";
            } else {
                echo "<p class='alert alert-danger mt-3'>Error: " . $conn->error . "</p>";
            }
        }
        ?>

        <!-- Lista de autores -->
        <div class="card shadow-lg mt-4">
            <h4 class="card-title">Lista de Autores</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Alias</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM autor";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$row['id_autor']}</td>";
                        echo "<td>{$row['nombres']}</td>";
                        echo "<td>{$row['apellidos']}</td>";
                        echo "<td>{$row['alias_de_autor']}</td>";
                        echo "<td>
                                <form action='autores.php' method='POST' class='d-inline' onsubmit='return confirmDelete()'>
                                    <input type='hidden' name='id_autor' value='{$row['id_autor']}'>
                                    <button type='submit' name='eliminar_autor' class='btn btn-danger btn-sm'>Eliminar</button>
                                </form>
                                <a href='editar_autor.php?id={$row['id_autor']}' class='btn btn-warning btn-sm'>Editar</a>
                              </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <a href="index.php" class="btn btn-secondary mt-3">Volver al inicio</a>
    </div>

    <script>
        function confirmDelete() {
            return confirm("¿Estás seguro de que quieres eliminar este autor?");
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
