CREATE DATABASE DaysiFExa02
USE DaysiFExa02

CREATE TABLE autor (
    id_autor INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(100),
    apellidos VARCHAR(100),
    alias_de_autor VARCHAR(100)
)

CREATE TABLE libros (
    id_libro INT AUTO_INCREMENT PRIMARY KEY,
    nombre_libro VARCHAR(255),
    year_publicacion INT,
    volumen INT,
    categoria VARCHAR(100),
    foto VARCHAR(255),
    id_autor INT,
    FOREIGN KEY (id_autor) REFERENCES autor(id_autor)
)