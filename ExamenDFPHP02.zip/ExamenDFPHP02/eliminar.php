<?php
include 'cn.php';

if (isset($_GET['id'])) {
    $id_libro = $_GET['id'];

    $stmt = $conn->prepare("DELETE FROM libros WHERE id_libro = ?");
    $stmt->bind_param("i", $id_libro);

    if ($stmt->execute()) {
        echo "<script>alert('Libro eliminado correctamente'); window.location='libros.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar el libro');</script>";
    }
    $stmt->close();
}
?>
