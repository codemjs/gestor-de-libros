<?php
include 'cn.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM autor WHERE id_autor='$id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<p class='alert alert-danger'>Autor no encontrado.</p>";
        exit;
    }
}

if (isset($_POST['editar_autor'])) {
    $id = $_POST['id_autor'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $alias = $_POST['alias'];

    $sql = "UPDATE autor SET nombres='$nombres', apellidos='$apellidos', alias_de_autor='$alias' WHERE id_autor='$id'";
    if ($conn->query($sql) === TRUE) {
        header("Location: autores.php?mensaje=Autor actualizado correctamente");
        exit;
    } else {
        echo "<p class='alert alert-danger'>Error: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Autor</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Editar Autor</h2>
        <div class="card shadow-lg p-4">
            <form action="editar_autor.php" method="POST">
                <input type="hidden" name="id_autor" value="<?php echo $row['id_autor']; ?>">
                <div class="mb-3">
                    <label class="form-label">Nombres:</label>
                    <input type="text" name="nombres" class="form-control" value="<?php echo $row['nombres']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Apellidos:</label>
                    <input type="text" name="apellidos" class="form-control" value="<?php echo $row['apellidos']; ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Alias:</label>
                    <input type="text" name="alias" class="form-control" value="<?php echo $row['alias_de_autor']; ?>">
                </div>
                <button type="submit" name="editar_autor" class="btn btn-primary">Actualizar Autor</button>
                <a href="autores.php" class="btn btn-secondary">Cancelar</a>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>