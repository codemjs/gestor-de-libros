<?php 
include 'cn.php'; 


if (!isset($conn)) {
    die("Error: La conexión a la base de datos no está establecida.");
}

$filter_name = isset($_GET['nombre_libro']) ? $_GET['nombre_libro'] : '';


$filter_author = isset($_GET['autor']) ? $_GET['autor'] : '';


$sql = "SELECT libros.*, autor.nombres, autor.apellidos FROM libros 
        INNER JOIN autor ON libros.id_autor = autor.id_autor WHERE 1=1";


if ($filter_name != '') {
    $sql .= " AND libros.nombre_libro LIKE '%$filter_name%'";
}


if ($filter_author != '') {
    $sql .= " AND autor.id_autor = '$filter_author'";
}

$result = $conn->query($sql);


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['insertar'])) {
    $nombre_libro = $_POST['nombre_libro'];
    $year_publicacion = $_POST['year_publicacion'];
    $volumen = $_POST['volumen'];
    $categoria = $_POST['categoria'];
    $id_autor = $_POST['id_autor'];
    
    
    $foto = $_FILES['foto']['name'];
    $target = "imagenes/" . basename($foto);
    
    if (move_uploaded_file($_FILES['foto']['tmp_name'], $target)) {
        $sql_insert = "INSERT INTO libros (nombre_libro, year_publicacion, volumen, categoria, id_autor, foto) 
                       VALUES ('$nombre_libro', '$year_publicacion', '$volumen', '$categoria', '$id_autor', '$target')";
        if ($conn->query($sql_insert) === TRUE) {
            echo "<script>alert('Libro insertado exitosamente');</script>";
        } else {
            echo "<script>alert('Error al insertar el libro');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Libros</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(to right, #f8f9fa, #e9ecef);
    color: #333;
    padding-top: 50px;
}

.container {
    max-width: 1000px;
    margin-top: 30px;
}

.header {
    text-align: center;
    margin-bottom: 30px;
    color: #0056b3;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1.5px;
}

.card {
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease-in-out;
    background: white;
}

.card:hover {
    transform: scale(1.02);
}

.card-title {
    font-size: 1.4rem;
    font-weight: bold;
    color: #007bff;
}

.btn-custom {
    background: linear-gradient(135deg, #007bff, #0056b3);
    color: white;
    border-radius: 8px;
    padding: 10px 18px;
    font-size: 1rem;
    transition: 0.3s ease-in-out;
    border: none;
}

.btn-custom:hover {
    background: linear-gradient(135deg, #0056b3, #003f80);
    transform: scale(1.05);
}

.btn-danger, .btn-warning {
    border-radius: 6px;
    transition: 0.3s ease-in-out;
}

.btn-danger:hover {
    background-color: #c82333;
    transform: scale(1.05);
}

.btn-warning:hover {
    background-color: #e0a800;
    transform: scale(1.05);
}

.btn-back {
    background-color: #f8f9fa;
    border: 1px solid #007bff;
    color: #007bff;
    padding: 10px 20px;
    border-radius: 8px;
    transition: 0.3s;
}

.btn-back:hover {
    background-color: #007bff;
    color: white;
    transform: scale(1.05);
}

.form-label {
    font-weight: bold;
    color: #555;
}

.form-control {
    border-radius: 8px;
    border: 1px solid #ccc;
    transition: 0.3s ease-in-out;
    padding: 10px;
}

.form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 8px rgba(0, 123, 255, 0.3);
}

.table {
    background: white;
    border-radius: 12px;
    overflow: hidden;
}

.table th {
    background: linear-gradient(135deg, #007bff, #0056b3);
    color: white;
    text-align: center;
    padding: 14px;
    font-size: 1rem;
    text-transform: uppercase;
}

.table td {
    vertical-align: middle;
    text-align: center;
    padding: 14px;
    font-size: 0.95rem;
}

.alert {
    font-size: 1.1em;
    padding: 12px;
    border-radius: 8px;
}

.table img {
    border-radius: 8px;
    width: 50px;
    height: 50px;
    object-fit: cover;
    transition: transform 0.3s;
}

.table img:hover {
    transform: scale(1.2);
}

    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Gestión de Libros</h2>
        </div>

        
        <div id="filtro-libros" class="content-section">
            <div class="card shadow-lg p-4">
                <h3 class="card-title">Filtrar por Nombre de Libro</h3>
                <form method="GET" action="">
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text" name="nombre_libro" class="form-control" placeholder="Nombre del libro" value="<?= htmlspecialchars($filter_name) ?>">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary w-100">Filtrar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        
        <div id="filtro-autor" class="content-section">
            <div class="card shadow-lg p-4">
                <h3 class="card-title">Filtrar por Autor</h3>
                <form method="GET" action="">
                    <div class="row">
                        <div class="col-md-8">
                            <select name="autor" class="form-control">
                                <option value="">Selecciona Autor</option>
                                <?php
                                
                                $author_sql = "SELECT * FROM autor";
                                $author_result = $conn->query($author_sql);
                                while ($author = $author_result->fetch_assoc()) {
                                    echo "<option value='{$author['id_autor']}'" . ($filter_author == $author['id_autor'] ? ' selected' : '') . ">{$author['nombres']} {$author['apellidos']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary w-100">Filtrar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div id="insertar-libro" class="content-section">
            <div class="card shadow-lg p-4">
                <h3 class="card-title">Insertar Libro</h3>
                <form method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-4">
                            <input type="text" name="nombre_libro" class="form-control" placeholder="Nombre del Libro" required>
                        </div>
                        <div class="col-md-4">
                            <input type="number" name="year_publicacion" class="form-control" placeholder="Año de Publicación" required>
                        </div>
                        <div class="col-md-4">
                            <input type="number" name="volumen" class="form-control" placeholder="Volumen" required>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-4">
                            <input type="text" name="categoria" class="form-control" placeholder="Categoría" required>
                        </div>
                        <div class="col-md-4">
                            <select name="id_autor" class="form-control" required>
                                <option value="">Selecciona Autor</option>
                                <?php
                                
                                $author_sql = "SELECT * FROM autor";
                                $author_result = $conn->query($author_sql);
                                while ($author = $author_result->fetch_assoc()) {
                                    echo "<option value='{$author['id_autor']}'>{$author['nombres']} {$author['apellidos']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <input type="file" name="foto" class="form-control" required>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <button type="submit" name="insertar" class="btn btn-success w-100">Insertar Libro</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        
        <div id="consultar-libros" class="content-section">
            <div class="card shadow-lg p-4">
                <h3 class="card-title">Lista de Libros</h3>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Año</th>
                            <th>Volumen</th>
                            <th>Categoría</th>
                            <th>Autor</th>
                            <th>Foto</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['id_libro']}</td>
                                        <td>{$row['nombre_libro']}</td>
                                        <td>{$row['year_publicacion']}</td>
                                        <td>{$row['volumen']}</td>
                                        <td>{$row['categoria']}</td>
                                        <td>{$row['nombres']} {$row['apellidos']}</td>
                                        <td><img src='{$row['foto']}' width='50'></td>
                                        <td>
                                            <a href='editar.php?id={$row['id_libro']}' class='btn btn-warning btn-sm'>Editar</a>
                                            <a href='eliminar.php?id={$row['id_libro']}' class='btn btn-danger btn-sm' onclick='return confirm(\"¿Estás seguro?\");'>Eliminar</a>
                                        </td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8' class='text-center'>No hay libros registrados.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        
        <div class="text-center mt-3">
            <a href="index.php" class="btn btn-back">Volver al Inicio</a>
        </div>

    </div>
</body>
</html>
