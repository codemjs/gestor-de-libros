<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteca</title>
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Poppins', sans-serif;
            margin: 0;
        }
        .library-container {
            background: white;
            padding: 2.5rem;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
            width: 100%;
            max-width: 400px;
        }
        .library-container h2 {
            margin-bottom: 20px;
            color: #333;
            font-weight: 600;
        }
        .library-container p {
            color: #666;
            margin-bottom: 20px;
        }
        .btn-library {
            display: block;
            width: 100%;
            padding: 12px;
            margin-bottom: 10px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            text-decoration: none;
            transition: 0.3s;
            cursor: pointer;
        }
        .btn-library.primary {
            background: #667eea;
            color: white;
        }
        .btn-library.primary:hover {
            background: #5a67d8;
            transform: scale(1.05);
        }
        .btn-library.success {
            background: #28a745;
            color: white;
        }
        .btn-library.success:hover {
            background: #218838;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="library-container">
        <h2>Bienvenido a la Biblioteca</h2>
        <p>Gestiona los autores y libros de manera sencilla.</p>
        <a href="autores.php" class="btn-library primary">Gestionar Autores</a>
        <a href="libros.php" class="btn-library success">Gestionar Libros</a>
    </div>
</body>
</html>
