<?php
include 'cn.php';

if (isset($_GET['id'])) {
    $id_libro = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM libros WHERE id_libro = ?");
    $stmt->bind_param("i", $id_libro);
    $stmt->execute();
    $result = $stmt->get_result();
    $libro = $result->fetch_assoc();
    $stmt->close();
}

if (isset($_POST['editar_libro'])) {
    $id_libro = $_POST['id_libro'];
    $nombre_libro = $_POST['nombre_libro'];
    $year_publicacion = $_POST['year_publicacion'];
    $volumen = $_POST['volumen'];
    $categoria = $_POST['categoria'];
    $id_autor = $_POST['id_autor'];
    
    $stmt = $conn->prepare("UPDATE libros SET nombre_libro=?, year_publicacion=?, volumen=?, categoria=?, id_autor=? WHERE id_libro=?");
    $stmt->bind_param("siisii", $nombre_libro, $year_publicacion, $volumen, $categoria, $id_autor, $id_libro);
    if ($stmt->execute()) {
        echo "<script>alert('Libro actualizado correctamente'); window.location='libros.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar el libro');</script>";
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Libro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Editar Libro</h2>
        <form action="editar.php" method="POST">
            <input type="hidden" name="id_libro" value="<?php echo $libro['id_libro']; ?>">
            <div class="mb-3">
                <label class="form-label">Nombre del Libro:</label>
                <input type="text" name="nombre_libro" class="form-control" value="<?php echo $libro['nombre_libro']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Año de Publicación:</label>
                <input type="number" name="year_publicacion" class="form-control" value="<?php echo $libro['year_publicacion']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Volumen:</label>
                <input type="number" name="volumen" class="form-control" value="<?php echo $libro['volumen']; ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Categoría:</label>
                <input type="text" name="categoria" class="form-control" value="<?php echo $libro['categoria']; ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Autor:</label>
                <select name="id_autor" class="form-control">
                    <?php
                    $sql = "SELECT * FROM autor";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        $selected = ($libro['id_autor'] == $row['id_autor']) ? "selected" : "";
                        echo "<option value='{$row['id_autor']}' $selected>{$row['nombres']} {$row['apellidos']}</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" name="editar_libro" class="btn btn-success">Actualizar</button>
            <a href="index.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>